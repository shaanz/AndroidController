package com.f5.bigip;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;

public class BIGIPSELECTOR extends AppCompatActivity {


    private EditText username;
    private EditText server;
    private EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bigipselector);


        Button loginButton = (Button) findViewById(R.id.email_sign_in_button);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                username = (EditText) findViewById(R.id.user);
                password = (EditText) findViewById(R.id.password);
                server = (EditText) findViewById(R.id.server);

                String user = username.getText().toString();
                String pass = password.getText().toString();
                String serv = server.getText().toString();

                Context ctx = getApplicationContext();
                Intent intent = new Intent(ctx, UserHome.class);
                intent.putExtra("user", user);
                intent.putExtra("pass",pass);
                intent.putExtra("serv",serv);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(intent);
            }
        });
    }
}

