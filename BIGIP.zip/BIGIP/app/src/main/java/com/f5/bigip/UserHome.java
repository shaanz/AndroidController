package com.f5.bigip;

import android.content.Context;
import android.content.Intent;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.os.AsyncTask;


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import	android.util.Base64;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;


import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.Response;
import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;


import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.JSONException;
import org.json.simple.parser.JSONParser;


public class UserHome extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    private static String user, pass, server;
    private static String vslist[];
    private static Context context;
    private static Spinner spinner;

    @Override



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);
        UserHome.context = getApplicationContext();
        user = getIntent().getStringExtra("user");
        pass = getIntent().getStringExtra("pass");
        server = getIntent().getStringExtra("serv");

         spinner = (Spinner) findViewById(R.id.spinner);

        // Get the list of VS
         new SendPostRequest().execute("getvslist");


        Button silverButton = (Button) findViewById(R.id.silver);
        silverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Silver Clicked ");
                String vs = getSelectedVS();
                new SendPostRequest().execute("silver",vs);

            }
        });

        Button goldButton = (Button) findViewById(R.id.gold);
        goldButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String vs = getSelectedVS();
                new SendPostRequest().execute("gold",vs);

            }
        });

        Button platButton = (Button) findViewById(R.id.plat);
        platButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String vs = getSelectedVS();
                new SendPostRequest().execute("plat",vs);

            }
        });

    }

       private String getSelectedVS(){
           Spinner spin = (Spinner) findViewById(R.id.spinner);
            return (String)spin.getSelectedItem();

       }

        //Performing action onItemSelected and onNothing selected
        @Override
        public void onItemSelected(AdapterView<?> arg0, View arg1, int position,long id) {
            Toast.makeText(getApplicationContext(), vslist[position], Toast.LENGTH_LONG).show();
        }


        @Override
        public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

        }

    public class SendPostRequest extends AsyncTask<String, Void, String> {

        protected void onPreExecute(){}



        protected String doInBackground(String... arg0) {

            System.out.println("Function Calles : " + arg0[0]);
            URL url = null;
            String msg = "F5 Demo App::";
            HttpsURLConnection urlConnection = null;
            BufferedReader br;
            DataOutputStream wr;
            String user = UserHome.user;
            String pass =UserHome.pass;
            String strurl = "https://"+UserHome.server+"/mgmt/tm/ltm/virtual";
            String updateVSURL = "https://"+UserHome.server+"/mgmt/tm/asm/policies/";
            String output;
            String vsnames[];
            String jsonString;
            String ba_string = user +":" + pass;
            String ba = Base64.encodeToString(ba_string.getBytes(),Base64.DEFAULT);
            System.out.println("ENCODED PASSWORD: " + ba);

            //ACCEPT ALL CERT - Do not do this in production code
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {

                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                        public void checkClientTrusted(
                                java.security.cert.X509Certificate[] certs, String authType) {
                        }
                        public void checkServerTrusted(
                                java.security.cert.X509Certificate[] certs, String authType) {
                        }
                    }
            };

            // Install the all-trusting trust manager
            try {
                SSLContext sc = SSLContext.getInstance("SSL");
                sc.init(null, trustAllCerts, new java.security.SecureRandom());
                HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
                HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String arg0, SSLSession arg1) {
                        return true;
                    }
                });
            } catch (Exception e) {
             e.printStackTrace();

            }

            //ACCEPT ALL CERT
            if(arg0[0].equalsIgnoreCase("getvslist")) {

                try {

                    url = new URL(strurl.trim());
                    urlConnection = (HttpsURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    //urlConnection.setDoOutput(true);
                    urlConnection.setRequestProperty("Accept", "application/json");
                    urlConnection.setRequestProperty("Authorization","Basic "+ ba);

                    br = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

                    output = br.readLine();
                    if(output != null){
                        vsnames = getVSNames(output);
                        UserHome.vslist=vsnames;
                        System.out.println("Got VSNAMES");
                        System.out.println(vsnames[0].toString() + vsnames[1].toString());
                    }
                 return new String("vslist");

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.d(msg, "URL Malformed");

                } finally {
                    urlConnection.disconnect();
                    Log.d(msg, "Disconnected");
                }


            }else if(arg0[0].equalsIgnoreCase("silver")||arg0[0].equalsIgnoreCase("gold")||arg0[0].equalsIgnoreCase("plat")){
                System.out.println("PRofile ato be attached" + arg0[0]);
                String vs = (String) arg0[1];
                String profile =  (String)arg0[0];
                String phash;
                 try {
                     if (profile.equalsIgnoreCase("Silver")) {
                         phash = "Oy7EN23ZS5WPaBgdXG96hA";

                     } else if(profile.equalsIgnoreCase("Gold")){
                         phash = "Oy7EN23ZS5WPaBgdXG96hA";
                     } else{
                         phash = "Oy7EN23ZS5WPaBgdXG96hA";
                     }
                    String upURL = ((updateVSURL.trim()).concat(phash)).trim();
                     System.out.println("NEW URL : "+ upURL);

                     url = new URL(upURL);
                     urlConnection = (HttpsURLConnection) url.openConnection();
                     urlConnection.setRequestMethod("PATCH");
                     urlConnection.setRequestProperty("Accept", "application/json");
                     urlConnection.setRequestProperty("Authorization","Basic "+ ba);
                     //urlConnection.setRequestMethod("POST");

                     wr = new DataOutputStream(urlConnection.getOutputStream());
                     // To get the JSON
                     String json  = "{ \"virtualServers\":[\"/Common/vs_app2\"] }";
                     wr.writeBytes(json);
                     wr.flush();
                     wr.close();

                     urlConnection.connect();

                     int respcode = urlConnection.getResponseCode();
                     String respmesg = urlConnection.getResponseMessage();

                     System.out.println(" STATUS : " + respcode );
                     System.out.println(" STATUS Message  : " + respmesg );



                 }catch (Exception e){
                     e.printStackTrace();
                 }

                Log.d(msg, "Setting Silver Profile: " + profile +" to Virtual Server :" +  vs);

                return profile + " " + vs;

            }else {

                System.out.println("Major Error! Coder is running away");
            }



            return new String("DONE");
        }
        protected void onPostExecute(String result) {

            super.onPostExecute(result);

           if (result.equalsIgnoreCase("vslist")) {
               Spinner spinner = UserHome.spinner;
               //spinner.setOnItemSelectedListener();
               ArrayAdapter aa = new ArrayAdapter(UserHome.context, android.R.layout.simple_spinner_item, UserHome.vslist);
               aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
               //Setting the ArrayAdapter data on the Spinner
               spinner.setAdapter(aa);
           } else if( result.contains("gold")||result.contains("silver")||result.contains("plat")){

               //Looper.prepare();
               Toast.makeText(UserHome.context, " Applying " + result, Toast.LENGTH_LONG).show();
               //Looper.loop();
           }else {

               Toast.makeText(UserHome.context, " Something Messed Up!", Toast.LENGTH_LONG).show();
           }


        }


        protected void onProgressUpdate(String... values) {
            // TODO Auto-generated method stub

            // Display current found address in a TextView
            // TextView txt = (TextView) findViewById(R.id.editText3);
            // System.out.println("Updte Alance" + values[0]);
            // txt.setText("Current Balance" + values[0]);

            super.onProgressUpdate();
        }

        private String[] getVSNames(String jsonList) {
            String vsnames [] = new String [20];
            try {
                JSONParser parser = new JSONParser();
                JSONObject json = (JSONObject) parser.parse(jsonList);
                System.out.println(json.toJSONString());
                System.out.println("VS NAME " + json.get("items"));
                JSONArray jobj2 = (JSONArray) json.get("items");
                System.out.println("Size of JSON Array " + jobj2.size());

                for (int i = 0; i < jobj2.size(); i++) {
                    System.out.println("VS NAME : " + ((JSONObject) jobj2.get(i)).get("name"));
                    vsnames[i] = (String) ((JSONObject) jobj2.get(i)).get("name");
                }



                int cnt=0;
                for (int i =0; i<vsnames.length; i++){
                    if(vsnames[i]!=null){
                        ++cnt;
                    }else{
                        break;
                    }

                }
                String vslisttrimmed[] = new String[cnt];
                for(int i=0;i<cnt;i++){
                    vslisttrimmed[i]=vsnames[i];
                }
                return vslisttrimmed;

            }catch(Exception e){
                e.printStackTrace();
            }

            return null;
        }

    }


}

